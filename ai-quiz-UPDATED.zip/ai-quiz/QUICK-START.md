# 🚀 QUICK START GUIDE - Deploy in 10 Minutes

## What You Have
✅ Complete AI Readiness Quiz with 10 questions
✅ 4 personalized AI personas with full program recommendations
✅ HubSpot form integration (already configured!)
✅ GBSB Global branding (colors, fonts)
✅ Social sharing functionality
✅ Mobile-responsive design

## Deploy RIGHT NOW (No Coding Needed!)

### STEP 1: Create GitHub Account (2 minutes)
1. Go to https://github.com/signup
2. Create free account with your email
3. Verify your email

### STEP 2: Upload Files (3 minutes)
1. Go to https://github.com/new
2. Repository name: `ai-summer-quiz`
3. Make it **Public**
4. Click **"Create repository"**
5. Click **"uploading an existing file"**
6. Drag ALL 7 files from the folder I gave you:
   - index.html
   - quiz.html
   - email-capture.html
   - results.html
   - styles.css
   - script.js
   - .gitignore
7. Click **"Commit changes"**

### STEP 3: Activate GitHub Pages (2 minutes)
1. Click **"Settings"** at top
2. Click **"Pages"** on left sidebar
3. Under "Source", choose **"main"** branch
4. Click **"Save"**
5. Wait 2-3 minutes

### STEP 4: Get Your Live URL (1 minute)
Your quiz is now live at:
```
https://YOUR-GITHUB-USERNAME.github.io/ai-summer-quiz/
```

**Example:** If your username is `gbsb-marketing`, the URL is:
```
https://gbsb-marketing.github.io/ai-summer-quiz/
```

## Test It! ✅
1. Open your URL in a browser
2. Take the quiz (test all 10 questions)
3. Submit your email on the form
4. Check HubSpot to confirm the lead appeared

## Add to Your Landing Page

### Option A: Button Link (Easiest)
Add this button to your WordPress landing page:
```html
<a href="https://YOUR-USERNAME.github.io/ai-summer-quiz/" 
   style="background: #C63228; color: white; padding: 15px 40px; 
          text-decoration: none; border-radius: 5px; font-weight: bold;">
   Discover Your AI Learning Path
</a>
```

### Option B: Embed Quiz Directly
```html
<iframe 
  src="https://YOUR-USERNAME.github.io/ai-summer-quiz/" 
  width="100%" 
  height="800px" 
  style="border: none;">
</iframe>
```

## Need to Make Changes?

### Update Any Text or Content:
1. Go to your GitHub repository
2. Click on the file you want to edit (e.g., `index.html`)
3. Click the pencil icon (✏️) to edit
4. Make your changes
5. Scroll down and click **"Commit changes"**
6. Changes go live in 1-2 minutes automatically!

### Add Your Logo:
1. Save your logo as `logo.png`
2. Go to your GitHub repository
3. Click **"Add file"** → **"Upload files"**
4. Upload `logo.png`
5. Edit each HTML file and replace the placeholder (instructions in README.md)

## Check Your Leads

All quiz submissions automatically go to HubSpot:
1. Login to HubSpot
2. Go to **Contacts** → **Contacts**
3. Look for new contacts with form submission activity

## Important Links

- **Your Quiz URL:** `https://YOUR-USERNAME.github.io/ai-summer-quiz/`
- **GitHub Repository:** `https://github.com/YOUR-USERNAME/ai-summer-quiz`
- **HubSpot Portal:** https://app.hubspot.com/contacts/48585497

## Need Help?

Common issues and fixes:

**Quiz not loading?**
- Wait 3-5 minutes after enabling GitHub Pages
- Check that "Source" in Settings → Pages is set to "main" branch
- Try clearing your browser cache

**Form not working?**
- Form should work automatically (already configured)
- Check HubSpot to ensure form is still active
- Verify you're connected to internet

**Want to change colors?**
- Edit `styles.css` file in GitHub
- Colors are at the very top in the `:root` section

## What's Captured?

When someone completes the quiz, you get:
- ✉️ Their email address
- 👤 Their name (if they provide it)
- 🎯 Their AI persona type (automatically tagged)
- 📅 Timestamp of completion

## Marketing Tips

1. **Social Media:** Share the quiz link on Instagram, LinkedIn
2. **Email Signature:** Add "Take our AI Readiness Quiz" link
3. **WhatsApp:** Send directly to prospects
4. **Landing Page:** Make it prominent with a CTA
5. **Retargeting:** Use quiz takers for Facebook/Instagram ads

## Success Checklist

Before you launch:
- [ ] Quiz loads correctly at your GitHub Pages URL
- [ ] All 10 questions display properly
- [ ] Email form submits successfully
- [ ] Test lead appears in HubSpot
- [ ] Results page shows correct persona
- [ ] Social share buttons work
- [ ] Mobile version looks good (test on phone)
- [ ] Application link goes to correct page

## Next Steps

1. ✅ Deploy to GitHub Pages (follow steps above)
2. ✅ Test the full user flow
3. ✅ Add to your WordPress landing page
4. ✅ Share on social media
5. ✅ Monitor leads in HubSpot
6. ✅ Follow up with leads about 25% early bird discount!

---

**Questions?** Check the full README.md for detailed documentation.

**Ready to launch?** Follow STEP 1 above right now! 🚀
